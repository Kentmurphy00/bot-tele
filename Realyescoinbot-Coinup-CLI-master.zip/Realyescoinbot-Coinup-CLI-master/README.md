# yescoin

+ Very simple, no need to login telegram

If the program closes, just install NET Runtime 8.0.6

[Download .NET 8](https://dotnet.microsoft.com/en-us/download/dotnet/8.0)

### How to work?

https://github.com/omidRR/Realyescoinbot-Coinup-CLI/assets/64539596/6219c00d-3a69-42ac-9a98-7e29840e9db8


## yescoin coinup site online

[realyescoinbot-coinup-Blazor](https://github.com/omidRR/realyescoinbot-coinup-Blazor)
